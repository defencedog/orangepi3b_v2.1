#!/bin/sh
HERE="$(dirname "$(readlink -f "${0}")")"
cd "${HERE}"
java -jar ./lib/jfs.jar
